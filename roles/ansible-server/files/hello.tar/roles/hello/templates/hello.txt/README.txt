This directory serves as an example of how to customize
templates for a role using the Ansible "with_first_found"
logic used in DIMS playbooks.

To apply the custom template in this directory, copy the
"hello.txt.j2.example" file to create the template:

  $ cp hello.txt.j2.example hello.txt.j2

Apply the "hello" role:

  $ dims.ansible-playbook --role hello


The output should include the following TASK output:

  TASK [hello : debug]
  ***********************************************************
  Monday 03 April 2017  16:45:39 -0700 (0:00:00.159)
  0:00:01.304 ********** 
  ok: [localhost] => {}
  
  MSG:
  
  Hello from localhost says "Hola!" (from /opt/dims/custom/roles/hello)
  
  
  msg: Hello from localhost says "Hola!" (from /opt/dims/custom/roles/hello)

When you are confident you understand how this works,
you may want to delete the template so that future
use of the "hello" role does not confuse things.
